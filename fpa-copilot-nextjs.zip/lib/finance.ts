export type Assumptions = {
  baseRevenue: number
  growth: number
  grossMargin: number
  payroll: number
  opex: number
  capex: number
}

export type FinancialResult = {
  revenue: number
  cogs: number
  grossProfit: number
  payroll: number
  opex: number
  ebitda: number
  ebitdaMargin: number
  capex: number
  cashProxy: number
}

export const BASE_ASSUMPTIONS: Assumptions = {
  baseRevenue: 12,
  growth: 10,
  grossMargin: 45,
  payroll: 2.5,
  opex: 1.8,
  capex: 0.7
}

export function calculate(a: Assumptions): FinancialResult {
  const revenue = a.baseRevenue * (1 + a.growth / 100)
  const grossProfit = revenue * (a.grossMargin / 100)
  const cogs = revenue - grossProfit
  const ebitda = grossProfit - a.payroll - a.opex
  const ebitdaMargin = revenue > 0 ? (ebitda / revenue) * 100 : 0
  const cashProxy = ebitda - a.capex

  return {
    revenue,
    cogs,
    grossProfit,
    payroll: a.payroll,
    opex: a.opex,
    ebitda,
    ebitdaMargin,
    capex: a.capex,
    cashProxy
  }
}

export function breakEvenRevenue(a: Assumptions, targetEbitda = 0): number | null {
  const gm = a.grossMargin / 100
  if (gm <= 0) return null
  return (a.payroll + a.opex + targetEbitda) / gm
}
