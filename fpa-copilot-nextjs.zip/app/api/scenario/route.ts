import { NextRequest, NextResponse } from 'next/server'

type ParsedScenario = {
  growth?: number
  grossMargin?: number
  payrollChangePct?: number
  opexChangePct?: number
}

function parseLocally(text: string): ParsedScenario {
  const t = text.toLowerCase()
  const out: ParsedScenario = {}

  let m = t.match(/revenue\s+(?:falls|drops|declines|decreases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.growth = -Number(m[1])

  m = t.match(/revenue\s+(?:rises|grows|increases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.growth = Number(m[1])

  m = t.match(/margin\s+(?:drops|falls|declines|decreases)\s+to\s+([\d.]+)%/)
  if (m) out.grossMargin = Number(m[1])

  m = t.match(/margin\s+(?:rises|improves|increases)\s+to\s+([\d.]+)%/)
  if (m) out.grossMargin = Number(m[1])

  m = t.match(/payroll\s+(?:rises|increases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.payrollChangePct = Number(m[1])

  m = t.match(/payroll\s+(?:falls|decreases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.payrollChangePct = -Number(m[1])

  m = t.match(/opex\s+(?:rises|increases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.opexChangePct = Number(m[1])

  m = t.match(/opex\s+(?:falls|decreases)\s+(?:by\s+)?([\d.]+)%/)
  if (m) out.opexChangePct = -Number(m[1])

  return out
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const text = String(body?.text ?? '')

  // MVP fallback parser.
  // Later, replace this with an OpenAI API call that returns structured JSON.
  const parsed = parseLocally(text)

  return NextResponse.json({ parsed })
}
